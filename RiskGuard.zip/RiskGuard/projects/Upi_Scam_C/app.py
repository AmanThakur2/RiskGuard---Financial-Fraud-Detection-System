
from flask import Flask, render_template, request, send_file
import pandas as pd
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
RESULT_FOLDER = 'results'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

def predict_fraud(df):
    # Placeholder fraud detection logic
    df['Fraud Prediction'] = df.apply(lambda row: '🚨' if row['is_vpn_used'] or row['is_remote_access'] or row['qr_code_used'] else '✅', axis=1)
    return df

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        file = request.files['file']
        if file:
            filepath = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(filepath)
            
            df = pd.read_csv(filepath)
            df = predict_fraud(df)
            result_path = os.path.join(RESULT_FOLDER, 'predicted_' + file.filename)
            df.to_csv(result_path, index=False)
            
            return render_template('index.html', tables=[df.to_html(classes='data', index=False)], download_link=result_path)
    
    return render_template('index.html', tables=None, download_link=None)

@app.route('/download/<filename>')
def download(filename):
    return send_file(os.path.join(RESULT_FOLDER, filename), as_attachment=True)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5010, debug=True)
