import joblib
import pandas as pd
from sklearn.preprocessing import StandardScaler

import joblib

model_path = "/Users/amanthakur/Documents/WORK/Projects/FInance_HACKATHON/Upi_Scam/data/upi_fraud_model.pkl"
scaler_path = "/Users/amanthakur/Documents/WORK/Projects/FInance_HACKATHON/Upi_Scam/data/scaler.pkl"

# Load the model and scaler
model = joblib.load(model_path)
scaler = joblib.load(scaler_path)

print("Model and scaler loaded successfully!")

# Step 1️⃣: Read CSV file (Ensure it has the same columns as training data)
file_path = "/Users/amanthakur/Documents/WORK/Projects/FInance_HACKATHON/Upi_Scam/data/transactions.csv"  # Change this to your actual file path
df = pd.read_csv(file_path)

# Step 2️⃣: Scale input data
df_scaled = scaler.transform(df)

# Step 3️⃣: Predict fraud
predictions = model.predict(df_scaled)

# Step 4️⃣: Add predictions to DataFrame
df["Fraud Prediction"] = ["Fraud" if pred == 1 else "Legitimate" for pred in predictions]

# Step 5️⃣: Display results
print(df.head(10))  # Show first 10 predictions

# Step 6️⃣: Save results to a new CSV file
df.to_csv("predicted_transactions.csv", index=False)
print("\n✅ Predictions saved to 'predicted_transactions.csv'")
