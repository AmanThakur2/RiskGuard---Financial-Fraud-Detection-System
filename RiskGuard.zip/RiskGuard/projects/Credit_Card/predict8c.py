from flask import Flask, render_template, request, send_file
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import io
import base64
from lime import lime_tabular

app = Flask(__name__)

# Generate synthetic dataset (same as before)
rng = np.random.default_rng(seed=42)
data_size = 250000
data = pd.DataFrame({
    "TransactionAmount": rng.integers(1, 10000, data_size),
    "TransactionTime": rng.integers(1, 1440, data_size),
    "IsForeignTransaction": rng.integers(0, 2, data_size),
    "IsHighRiskCountry": rng.integers(0, 2, data_size),
    "DeviceChange": rng.integers(0, 2, data_size),
    "VelocityFlag": rng.integers(0, 2, data_size),
    "CardPresent": rng.integers(0, 2, data_size),
    "BehaviorDeviation": rng.integers(0, 2, data_size),
    "RepeatedPattern": rng.integers(0, 2, data_size),
})

def calculate_fraud_score(row):
    score = 0
    score += 3 if row["TransactionAmount"] > 5000 else 0
    score += 2 if row["TransactionTime"] > 1200 else 0
    score += 2 * row["IsForeignTransaction"]
    score += 3 * row["IsHighRiskCountry"]
    score += 1 * row["DeviceChange"]
    score += 1 * row["VelocityFlag"]
    score += 1 * row["CardPresent"]
    score += 1 * row["BehaviorDeviation"]
    score += 1 * row["RepeatedPattern"]
    return 1 if score >= 7 else 0

data['IsFraud'] = data.apply(calculate_fraud_score, axis=1)
features = data.drop(columns=["IsFraud"])
labels = data["IsFraud"]
X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.2, random_state=42)
model = RandomForestClassifier()
model.fit(X_train, y_train)

def predict_fraud_and_explain(file_path, output_file_path="output_with_explanations.csv"):
    try:
        input_data = pd.read_csv(file_path)
        expected_columns = list(features.columns)

        if not all(col in input_data.columns for col in expected_columns):
            missing_cols = [col for col in expected_columns if col not in input_data.columns]
            return f"Error: CSV file is missing the following columns: {missing_cols}", None

        input_data = input_data[expected_columns]
        predictions = model.predict(input_data)
        input_data['IsFraudPredicted'] = predictions

        explanations = []
        for index, row in input_data.iterrows():
            if row['IsFraudPredicted'] == 1:
                cause = "Potential Fraud: "
                if row['TransactionAmount'] > 5000:
                    cause += "High Transaction Amount, "
                if row['TransactionTime'] > 1200:
                    cause += "Late Night Transaction, "
                if row['IsForeignTransaction'] == 1:
                    cause += "Foreign Transaction, "
                if row['IsHighRiskCountry'] == 1:
                    cause += "High Risk Country, "
                if row['DeviceChange'] == 1:
                    cause += "Device Change, "
                if row['VelocityFlag'] == 1:
                    cause += "Velocity Flag, "
                if row['CardPresent'] == 1:
                    cause += "Card Present, "
                if row['BehaviorDeviation'] == 1:
                    cause += "Behavior Deviation, "
                if row['RepeatedPattern'] == 1:
                    cause += "Repeated Pattern, "

                explanations.append(cause.rstrip(', '))
            else:
                explanations.append("Transaction Safe")

        input_data['FraudCause'] = explanations
        input_data.to_csv(output_file_path, index=False)
        return output_file_path, input_data

    except FileNotFoundError:
        return f"Error: File not found at {file_path}", None
    except Exception as e:
        return f"An error occurred: {e}", None

def generate_graph(df):
    plt.figure(figsize=(12, 6))
    plt.plot(df['TransactionTime'], df['TransactionAmount'], marker='o', linestyle='-')

    fraud_points = df[df['IsFraudPredicted'] == 1]
    plt.scatter(fraud_points['TransactionTime'], fraud_points['TransactionAmount'], color='red', label='Fraud Detected', s=50)

    plt.title('Transaction Amount vs. Time with Fraud Highlights')
    plt.xlabel('Transaction Time')
    plt.ylabel('Transaction Amount')
    plt.legend()
    plt.grid(True)

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode('utf8')
    plt.close()
    return plot_url

def generate_lime_plot(df, model, features):
    try:
        explainer = lime_tabular.LimeTabularExplainer(
            df[features].values,
            feature_names=features,
            class_names=['Safe', 'Fraud'],
            mode='classification'
        )

        explanations = []
        for i in range(min(10, len(df))):  # Generate LIME for up to 10 samples
            exp = explainer.explain_instance(
                df[features].iloc[i].values,
                model.predict_proba,
                num_features=len(features)
            )
            explanations.append(exp.as_pyplot_figure())

        img = io.BytesIO()
        explanations[0].savefig(img, format='png', bbox_inches='tight')  # Use the first explanation to generate image
        img.seek(0)
        lime_plot_url = base64.b64encode(img.getvalue()).decode('utf8')
        plt.close('all') # close all figures.
        return lime_plot_url
    except Exception as e:
        print(f"Error generating LIME plot: {e}")
        return None

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            return render_template('index.html', error='No file part')
        file = request.files['file']
        if file.filename == '':
            return render_template('index.html', error='No selected file')
        if file:
            file_path = "uploaded_file.csv"
            file.save(file_path)
            output_data, df = predict_fraud_and_explain(file_path)
            os.remove(file_path)

            if df is not None:
                plot_url = generate_graph(df)
                lime_plot_url = generate_lime_plot(df, model, features.columns)

                print(f"LIME Plot URL: {lime_plot_url}")  # Debugging line

                display_df = df[['TransactionAmount', 'TransactionTime', 'FraudCause']]
                return render_template('results.html', data=display_df.to_html(), download_link=output_data, plot_url=plot_url, lime_plot_url=lime_plot_url)
            else:
                return render_template('index.html', error=output_data)

    return render_template('index.html')

@app.route('/download/<filename>')
def download_file(filename):
    return send_file(filename, as_attachment=True, download_name="fraud_results.csv")

if __name__ == '__main__':
    app.run(debug=True, port=5001)