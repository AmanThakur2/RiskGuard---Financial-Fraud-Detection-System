import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import time as time_module  # Fixed import

# Set random seed for reproducibility
np.random.seed(42)

# Number of transactions to generate
num_transactions = 250000

print(f"Generating {num_transactions} credit card transactions...")
start_time = time_module.time()  # Fixed time call

# Create empty dataframe with pre-allocated lists for better performance
data = {
    'TransactionAmount': [0] * num_transactions,
    'TransactionTime': [0] * num_transactions,
    'IsForeignTransaction': [0] * num_transactions,
    'IsHighRiskCountry': [0] * num_transactions,
    'DeviceChange': [0] * num_transactions,
    'VelocityFlag': [0] * num_transactions,
    'CardPresent': [0] * num_transactions,
    'BehaviorDeviation': [0] * num_transactions,
    'RepeatedPattern': [0] * num_transactions,
    'IsFraud': [0] * num_transactions
}

# Define merchant categories
merchant_categories = ['Groceries', 'Restaurant', 'Retail', 'Travel', 'Online', 'Gas', 'Casino', 'Electronics', 'Jewelry', 'Healthcare']
fraud_prone_categories = ['Online', 'Casino', 'Jewelry', 'Electronics']

# Pre-generate some random arrays for better performance
is_fraud_array = np.random.choice([0, 1], size=num_transactions, p=[0.9, 0.1])
random_uniform = np.random.random(num_transactions)

# Generate data
for i in range(num_transactions):
    if i % 25000 == 0 and i > 0:
        elapsed = time_module.time() - start_time  # Fixed time call
        print(f"Generated {i} transactions ({i/num_transactions*100:.1f}%) - Elapsed: {elapsed:.1f}s")

    # Get pre-generated fraud flag
    is_fraud = is_fraud_array[i]

    # Transaction amount
    if is_fraud:
        # Fraudulent transactions tend to be either very small (testing) or large
        if random_uniform[i] < 0.3:
            amount = np.random.uniform(0.5, 10)  # Small test amounts
        else:
            amount = np.random.uniform(500, 5000)  # Large amounts
    else:
        # Regular transactions follow a different distribution
        amount = np.random.lognormal(mean=4, sigma=1)  # Most transactions cluster around mid-range values

    data['TransactionAmount'][i] = round(amount, 2)

    # Transaction time (seconds since start of day, 0-86400)
    if is_fraud:
        # Fraudulent transactions more common during night hours (0-6am, 0-21600 seconds)
        if np.random.random() < 0.7:
            time = np.random.uniform(0, 21600)
        else:
            time = np.random.uniform(0, 86400)
    else:
        # Regular transactions more common during waking hours
        time = np.random.uniform(28800, 75600)  # 8am-9pm

    data['TransactionTime'][i] = int(time)

    # Foreign transaction
    if is_fraud:
        is_foreign = np.random.choice([0, 1], p=[0.3, 0.7])
    else:
        is_foreign = np.random.choice([0, 1], p=[0.9, 0.1])
    data['IsForeignTransaction'][i] = is_foreign

    # High risk country
    if is_fraud and is_foreign:
        is_high_risk = np.random.choice([0, 1], p=[0.2, 0.8])
    elif is_foreign:
        is_high_risk = np.random.choice([0, 1], p=[0.7, 0.3])
    else:
        is_high_risk = 0
    data['IsHighRiskCountry'][i] = is_high_risk

    # Device change
    if is_fraud:
        device_change = np.random.choice([0, 1], p=[0.2, 0.8])
    else:
        device_change = np.random.choice([0, 1], p=[0.95, 0.05])
    data['DeviceChange'][i] = device_change

    # Velocity flag
    if is_fraud:
        velocity = np.random.choice([0, 1], p=[0.3, 0.7])
    else:
        velocity = np.random.choice([0, 1], p=[0.98, 0.02])
    data['VelocityFlag'][i] = velocity

    # Card present
    if is_fraud:
        card_present = np.random.choice([0, 1], p=[0.8, 0.2])
    else:
        card_present = np.random.choice([0, 1], p=[0.3, 0.7])
    data['CardPresent'][i] = card_present

    # Behavior deviation
    if is_fraud:
        behavior_dev = np.random.choice([0, 1], p=[0.1, 0.9])
    else:
        behavior_dev = np.random.choice([0, 1], p=[0.9, 0.1])
    data['BehaviorDeviation'][i] = behavior_dev

    # Repeated pattern
    if is_fraud:
        repeated = np.random.choice([0, 1], p=[0.4, 0.6])
    else:
        repeated = np.random.choice([0, 1], p=[0.95, 0.05])
    data['RepeatedPattern'][i] = repeated

    # Set fraud label (already set in pre-generated array)
    data['IsFraud'][i] = is_fraud

# Create DataFrame
df = pd.DataFrame(data)

# Add a few more complex patterns and correlations for realism

# 1. Add some sequential fraudulent transactions (common pattern in real fraud)
seq_fraud_start = np.random.randint(0, num_transactions - 50, size=100)
for start in seq_fraud_start:
    seq_length = np.random.randint(3, 8)
    for j in range(seq_length):
        if start + j < num_transactions:
            idx = start + j
            df.loc[idx, 'IsFraud'] = 1
            df.loc[idx, 'VelocityFlag'] = 1
            df.loc[idx, 'BehaviorDeviation'] = 1

            # Make sequential frauds have similar amounts
            base_amount = np.random.uniform(50, 500)
            df.loc[idx, 'TransactionAmount'] = round(base_amount * (0.9 + 0.2 * np.random.random()), 2)

            # Make them happen close in time
            base_time = np.random.uniform(0, 86400 - 600)
            df.loc[idx, 'TransactionTime'] = int(base_time + j * np.random.uniform(60, 300))

# Calculate total execution time
execution_time = time_module.time() - start_time  # Fixed time call
print(f"Dataset generation completed in {execution_time:.2f} seconds")

# Display data summary
print(f"\nTotal transactions: {len(df)}")
print(f"Fraudulent transactions: {df['IsFraud'].sum()} ({df['IsFraud'].mean()*100:.1f}%)")
print(f"Average transaction amount: ${df['TransactionAmount'].mean():.2f}")

# Save to CSV
filename = 'credit_card_fraud_dataset_250k.csv'
df.to_csv(filename, index=False)
print(f"\nDataset saved to {filename}")

# Generate sample data (first 10 rows)
df.head(10)