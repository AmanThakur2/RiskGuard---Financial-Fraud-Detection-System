import requests

# API Endpoint
url = "http://127.0.0.1:5000/trigger_transaction"

# Manually enter transaction details
amount = float(input("Enter amount: "))
device = input("Enter device name: ")
location = input("Enter location: ")

transaction = {
    "amount": amount,
    "device": device,
    "location": location
}

# Send transaction request
response = requests.post(url, json=transaction)

# Print response
print(response.json())
