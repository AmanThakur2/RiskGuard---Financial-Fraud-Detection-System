from flask import Flask, render_template, request, send_file
import pandas as pd
import os

app = Flask(__name__, template_folder="/Users/amanthakur/Documents/WORK/Projects/FInance_HACKATHON_C/templates")
UPLOAD_FOLDER = 'uploads'
RESULT_FOLDER = 'results'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

def predict_fraud(df):
    # Placeholder fraud detection logic
    df['Fraud Prediction'] = df.apply(lambda row: '🚨 Fraud' if row['is_vpn_used'] or row['is_remote_access'] or row['qr_code_used'] else '✅ Legitimate', axis=1)
    return df

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        file = request.files['csvFile']  # Ensure it matches the input name in bulk1.html
        if file:
            filepath = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(filepath)
            
            df = pd.read_csv(filepath)
            df = predict_fraud(df)
            result_path = os.path.join(RESULT_FOLDER, 'predicted_' + file.filename)
            df.to_csv(result_path, index=False)
            
            return render_template('bulk11.html', tables=[df.to_html(classes='table table-striped', index=False)], download_link=result_path)
    
    return render_template('bulk11.html', tables=None, download_link=None)

@app.route('/download/<filename>')
def download(filename):
    return send_file(os.path.join(RESULT_FOLDER, filename), as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
