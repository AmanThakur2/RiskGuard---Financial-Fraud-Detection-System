

http://127.0.0.1:5001 - Bulk Credit Card  http://127.0.0.1:5004 - Manual Credit Card 
http://127.0.0.1:5010 - Bulk UPI 
http://127.0.0.1:5000 - Mock Bank APi


Run Statements:- 
 Main :- http://127.0.0.1:5502/templates/index.html 
Mock Bank Api :-         1. python3 /Users/amanthakur/Documents/WORK/Projects/FInance_HACKATHON_C/projects/Bank_api/app.py
       2. python3 /Users/amanthakur/Documents/WORK/Projects/FInance_HACKATHON/Bank_api/trigger_transaction.py

Credit Card :- 
       1. INDIVIDUAL - python3 /Users/amanthakur/Documents/WORK/Projects/FInance_HACKATHON_C/projects/Credit_Card/app.py
       2. Bulk - python3 /Users/amanthakur/Documents/WORK/Projects/FInance_HACKATHON_C/projects/Credit_Card/predict8c.py
 UPI :- python3 /Users/amanthakur/Documents/WORK/Projects/FInance_HACKATHON_C/projects/Upi_Scam_C/app.py
